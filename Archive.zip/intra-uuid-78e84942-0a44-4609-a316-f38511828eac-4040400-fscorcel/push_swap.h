/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fscorcel <fscorcel@student.42barcel>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/07 16:18:23 by fscorcel          #+#    #+#             */
/*   Updated: 2022/03/16 15:37:54 by fscorcel         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PUSH_SWAP_H
# define PUSH_SWAP_H

# include <stdlib.h>
# include <unistd.h>
# include "libft/libft.h"

void	sa(t_stack **a, int x);
void	sb(t_stack **b, int x);
void	ss(t_stack **a, t_stack **b, int x);
void	swappie(t_stack **st);
void	rotator(t_stack **st);
void	ra(t_stack **a, int x);
void	rb(t_stack **b, int x);
int		roterse(t_stack **st);
void	rr(t_stack **a, t_stack **b, int x);
void	rra(t_stack **a, int x);
void	rrb(t_stack **b, int x);
void	rrr(t_stack **a, t_stack **b, int x);
int		pushie(t_stack **dst, t_stack **source);
void	pa(t_stack **a, t_stack **b, int x);
void	pb(t_stack **a, t_stack **b, int x);
void	args_checker(int argc, char **argv);
int		howfar(t_stack **st, int i);
int		thesmallest(t_stack **st, int val);
void	stackmaker(t_stack **st, int ac, char **av);
void	sorter(t_stack **a, t_stack **b);
void	shorties(t_stack **a, t_stack **b);
int		is_done(t_stack **st);
void	stooges3(t_stack **a);
void	fantastic4(t_stack **a, t_stack **b);
void	giveme5(t_stack **a, t_stack **b);
void	hard_sort(t_stack **a, t_stack **b);
void	free_stack(t_stack **st);
void	free_str(char **s);
void	puterror(char *s);

#endif
