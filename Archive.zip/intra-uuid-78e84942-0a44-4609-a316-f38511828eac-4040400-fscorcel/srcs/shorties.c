/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   shorties.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fscorcel <fscorcel@student.42barcel>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/07 16:18:23 by fscorcel          #+#    #+#             */
/*   Updated: 2022/03/16 15:46:46 by fscorcel         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../push_swap.h"

static void	therest(t_stack *aux, int smallest, t_stack **a)
{
	if (aux->next->marker == smallest)
		ra(a, 1);
	else
	{
		sa(a, 1);
		rra(a, 1);
	}
}

void	stooges3(t_stack **a)
{
	t_stack		*aux;
	int			smallest;
	int			smaller;

	aux = *a;
	smallest = thesmallest(a, -1);
	smaller = thesmallest(a, smallest);
	if (is_done(a))
		return ;
	if (aux->marker == smallest && aux->next->marker != smaller)
	{
		ra(a, 1);
		sa(a, 1);
		rra(a, 1);
	}
	else if (aux->marker == smaller)
	{
		if (aux->next->marker == smallest)
			sa(a, 1);
		else
			rra(a, 1);
	}
	else
		therest(aux, smallest, a);
}

void	fantastic4(t_stack **a, t_stack **b)
{
	int	gap;

	if (is_done(a))
		return ;
	gap = howfar(a, thesmallest(a, -1));
	if (gap == 1)
		ra(a, 1);
	if (gap == 2)
	{
		ra(a, 1);
		ra(a, 1);
	}
	if (gap == 3)
		rra(a, 1);
	if (is_done(a))
		return ;
	pb(a, b, 1);
	stooges3(a);
	pa(a, b, 1);
}

void	giveme5(t_stack **a, t_stack **b)
{
	int	gap;

	gap = howfar(a, thesmallest(a, -1));
	if (gap == 1)
		ra(a, 1);
	if (gap == 2)
	{
		ra(a, 1);
		ra(a, 1);
	}
	if (gap == 3)
	{
		rra(a, 1);
		rra(a, 1);
	}
	if (gap == 4)
		rra(a, 1);
	if (is_done(a))
		return ;
	pb(a, b, 1);
	fantastic4(a, b);
	pa(a, b, 1);
}
