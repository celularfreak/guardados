/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   alrigthy.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fscorcel <fscorcel@student.42barcel>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/05 13:45:32 by fscorcel          #+#    #+#             */
/*   Updated: 2022/03/16 15:46:00 by fscorcel         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../push_swap.h"

static int	no_clooneys(char **argv, int n, int i)
{
	while (--i >= 1)
	{
		if (ft_atoi(argv[i]) == n)
			return (1);
	}
	return (0);
}

static int	no_limits(char *argv, int i)
{
	int	len;

	len = ft_strlen(argv) - 1;
	while (argv[i])
	{
		if (argv[0] == '-' && ft_strlen(argv) > 11)
			return (0);
		if (argv[0] == '-' && argv[len] > '8' && ft_strlen(argv) == 11)
			return (0);
		if (argv[0] != '-' && ft_strlen(argv) > 10)
			return (0);
		if (argv[0] != '-' && ft_strlen(argv) == 10 && argv[len] > '7')
			return (0);
		i++;
	}
	return (1);
}

int	is_done(t_stack **st)
{
	t_stack	*aux;

	aux = *st;
	while (aux && aux->next)
	{
		if (aux->val > aux->next->val)
			return (0);
		aux = aux->next;
	}
	return (1);
}

void	args_checker(int argc, char **argv)
{
	int		i;
	long	tmp;
	char	**args;	

	i = 0;
	if (argc == 2)
		args = ft_split(argv[1], ' ');
	else
	{
		i = 1;
		args = argv;
	}
	while (args[i])
	{
		tmp = ft_atoi(args[i]);
		if (!ft_isalnum(args[i]))
			puterror("Error\n");
		if (!no_limits(args[i], 0))
			puterror("Error\n");
		if (no_clooneys(args, tmp, i))
			puterror("Error\n");
		i++;
	}
	if (argc == 2)
		free_str(args);
}

int	howfar(t_stack **st, int i)
{
	t_stack		*aux;
	int			dst;

	dst = 0;
	aux = *st;
	while (aux)
	{
		if (aux->marker == i)
			break ;
		dst++;
		aux = aux->next;
	}
	return (dst);
}
