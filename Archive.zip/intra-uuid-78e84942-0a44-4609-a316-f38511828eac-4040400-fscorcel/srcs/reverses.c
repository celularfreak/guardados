/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   reverses.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fscorcel <fscorcel@student.42barcel>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/07 16:18:23 by fscorcel          #+#    #+#             */
/*   Updated: 2022/03/16 15:40:58 by fscorcel         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../push_swap.h"

int	roterse(t_stack **st)
{
	t_stack	*top;
	t_stack	*bottom;

	if (ft_lstsize(*st) < 2)
		return (-1);
	top = *st;
	bottom = ft_lstlast(top);
	while (top)
	{
		if (top->next->next == NULL)
		{
			top->next = NULL;
			break ;
		}
		top = top->next;
	}
	bottom->next = *st;
	*st = bottom;
	return (0);
}

void	rra(t_stack **a, int x)
{
	if (roterse(a) == -1)
		return ;
	if (x == 1)
		ft_putstr_fd("rra\n", 1);
}

void	rrb(t_stack **b, int x)
{
	if (roterse(b) == -1)
		return ;
	if (x == 1)
		ft_putstr_fd("rrb\n", 1);
}

void	rrr(t_stack **a, t_stack **b, int x)
{
	if ((ft_lstsize(*a) < 2) || (ft_lstsize(*b) < 2))
		return ;
	roterse(a);
	roterse(b);
	if (x == 1)
		ft_putstr_fd("rrr\n", 1);
}
