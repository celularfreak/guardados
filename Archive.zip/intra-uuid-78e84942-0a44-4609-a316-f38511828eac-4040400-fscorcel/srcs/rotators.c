/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rotators.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fscorcel <fscorcel@student.42barcel>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/07 16:18:23 by fscorcel          #+#    #+#             */
/*   Updated: 2022/03/16 15:41:08 by fscorcel         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../push_swap.h"

void	rotator(t_stack **st)
{
	t_stack	*top;
	t_stack	*bottom;

	if (ft_lstsize(*st) < 2)
		return ;
	top = *st;
	bottom = ft_lstlast(top);
	*st = top->next;
	top->next = NULL;
	bottom->next = top;
}

void	ra(t_stack **a, int x)
{
	rotator(a);
	if (x == 1)
		ft_putstr_fd("ra\n", 1);
}

void	rb(t_stack **b, int x)
{
	rotator(b);
	if (x == 1)
		ft_putstr_fd("rb\n", 1);
}

void	rr(t_stack **a, t_stack **b, int x)
{
	if ((ft_lstsize(*a) < 2) || (ft_lstsize(*b) < 2))
		return ;
	rotator(a);
	rotator(b);
	if (x == 1)
		ft_putstr_fd("rr\n", 1);
}
