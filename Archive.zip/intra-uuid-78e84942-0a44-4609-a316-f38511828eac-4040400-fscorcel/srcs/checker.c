/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   checker.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fscorcel <fscorcel@student.4)barcel>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 10/03/07 16:18:03 by fscorcel            #+#    #+#             */
/*   Updated: 2022/03/21 12:46:52 by fscorcel         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../push_swap.h"

static void	checkmaker(t_stack **stack, int argc, char **argv)
{
	t_stack		*new;
	char		**args;
	int			i;

	i = 0;
	if (argc == 2)
	{
		args = ft_split(argv[1], ' ');
	}
	else
	{
		i = 1;
		args = argv;
	}
	while (args[i])
	{
		new = ft_lstnew(ft_atoi(args[i]));
		ft_lstadd_back(stack, new);
		i++;
	}
	if (argc == 2)
		free_str(args);
}

static int	terminator(char *needle, int len)
{
	int		len2;
	char	*commands;
	int		i;

	i = -1;
	commands = "ra rb rr sa sb ss rra rrb rrr pa pb";
	if (needle[0] == '\0')
		return (0);
	len2 = ft_strlen(needle) - 1;
	if (len2 == 1)
		return (0);
	while (needle[++i])
	{
		if (needle[i] == ' ')
			return (0);
	}
	while (*commands != '\0' && len-- >= len2)
	{
		if (*commands == *needle && ft_strncmp(commands, needle, len2) == 0)
			return (1);
		commands++;
	}
	return (0);
}

static int	cmd_checker2(char *s, t_stack **a, t_stack **b)
{
	if (!(ft_strncmp(s, "rra", 3)))
		rra(a, 0);
	if (!(ft_strncmp(s, "rrb", 3)))
		rrb(b, 0);
	if (!(ft_strncmp(s, "rrr", 3)))
		rrr(a, b, 0);
	if (!(ft_strncmp(s, "pa", 2)))
		pa(a, b, 0);
	if (!(ft_strncmp(s, "pb", 2)))
		pb(a, b, 0);
	else
	{
		if (!terminator(s, 35))
			puterror("Error\n");
		return (0);
	}
	return (1);
}

static int	cmd_checker(char *s, t_stack **a, t_stack **b)
{
	if (!(ft_strncmp(s, "ra", (2))))
		ra(a, 0);
	if (!(ft_strncmp(s, "rb", 2)))
		rb(b, 0);
	if (!(ft_strncmp(s, "rr", 2)))
		rr(a, b, 0);
	if (!(ft_strncmp(s, "sa", 2)))
		sa(a, 0);
	if (!(ft_strncmp(s, "sb", 2)))
		sb(b, 0);
	if (!(ft_strncmp(s, "ss", 2)))
		ss(a, b, 0);
	else
		return (cmd_checker2(s, a, b));
	return (1);
}

int	main(int ac, char **av)
{
	t_stack		*a;
	t_stack		*b;
	char		*str;

	if (ac < 2)
		return (0);
	args_checker(ac, av);
	checkmaker(&a, ac, av);
	str = get_next_line(0);
	while (str)
	{
		cmd_checker(str, &a, &b);
		free(str);
		str = get_next_line(0);
	}
	if (ac == 6 && !(is_done(&a) && is_done(&b)))
	{
		a = b;
	}
	if ((is_done(&a) && !(b)))
		ft_putstr_fd("\033[1;32mOK\n", 1);
	else
		ft_putendl_fd("\033[1;31mKO", 1);
}
