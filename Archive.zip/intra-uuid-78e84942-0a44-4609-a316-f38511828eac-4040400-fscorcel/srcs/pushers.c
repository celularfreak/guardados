/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pushers.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fscorcel <fscorcel@student.42barcel>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/11 16:33:02 by fscorcel          #+#    #+#             */
/*   Updated: 2022/03/16 15:40:51 by fscorcel         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../push_swap.h"

int	pushie(t_stack **dst, t_stack **source)
{
	t_stack	*aux;
	t_stack	*top_source;
	t_stack	*top_dst;

	if (ft_lstsize(*source) == 0)
		return (-1);
	top_dst = *dst;
	top_source = *source;
	aux = top_source;
	top_source = top_source->next;
	*source = top_source;
	if (!top_dst)
	{
		top_dst = aux;
		top_dst->next = NULL;
		*dst = top_dst;
	}
	else
	{
		aux->next = top_dst;
		*dst = aux;
	}
	return (0);
}

void	pa(t_stack **a, t_stack **b, int x)
{
	if (pushie(a, b) == -1)
		return ;
	if (x == 1)
		ft_putstr_fd("pa\n", 1);
}

void	pb(t_stack **a, t_stack **b, int x)
{
	if (pushie(b, a) == -1)
		return ;
	if (x == 1)
		ft_putstr_fd("pb\n", 1);
}
