/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   easyfix.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fscorcel <fscorcel@student.42barcel>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/05 13:45:47 by fscorcel          #+#    #+#             */
/*   Updated: 2022/03/16 15:46:31 by fscorcel         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../push_swap.h"

void	shorties(t_stack **a, t_stack **b)
{
	int	len;

	if (is_done(a) || !ft_lstsize(*a))
		return ;
	len = ft_lstsize(*a);
	if (len == 2)
		sa(a, 1);
	else if (len == 3)
		stooges3(a);
	else if (len == 4)
		fantastic4(a, b);
	else if (len == 5)
		giveme5(a, b);
}

void	sorter(t_stack **a, t_stack **b)
{
	if (ft_lstsize(*a) <= 5)
		shorties(a, b);
	else
		hard_sort(a, b);
}

int	thesmallest(t_stack **st, int val)
{
	t_stack		*aux;
	int			smallest;

	aux = *st;
	smallest = aux->marker;
	while (aux->next)
	{
		aux = aux->next;
		if ((aux->marker < smallest) && aux->marker != val)
			smallest = aux->marker;
	}
	return (smallest);
}
