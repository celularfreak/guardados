/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   algorythm.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fscorcel <fscorcel@student.42barcel>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/07 16:18:23 by fscorcel          #+#    #+#             */
/*   Updated: 2022/03/16 15:45:23 by fscorcel         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../push_swap.h"

static int	get_max_bits(t_stack **stack)
{
	t_stack		*top;
	int			max;
	int			max_bits;

	top = *stack;
	max = top->marker;
	max_bits = 0;
	while (top)
	{
		if (top->marker > max)
			max = top->marker;
		top = top->next;
	}
	while ((max >> max_bits) != 0)
		max_bits++;
	return (max_bits);
}

void	hard_sort(t_stack **a, t_stack **b)
{
	t_stack		*top_a;
	int			i;
	int			j;
	int			size;
	int			max_bits;

	i = 0;
	top_a = *a;
	size = ft_lstsize(top_a);
	max_bits = get_max_bits(a);
	while (i < max_bits)
	{
		j = 0;
		while (j++ < size)
		{
			top_a = *a;
			if (((top_a->marker >> i) & 1) == 1)
				ra(a, 1);
			else
				pb(a, b, 1);
		}
		while (ft_lstsize(*b) != 0)
			pa(a, b, 1);
		i++;
	}
}
