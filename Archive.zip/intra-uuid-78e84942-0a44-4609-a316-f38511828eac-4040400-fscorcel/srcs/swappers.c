/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   swappers.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fscorcel <fscorcel@student.42barcel>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/05 13:45:47 by fscorcel          #+#    #+#             */
/*   Updated: 2022/03/16 15:41:27 by fscorcel         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../push_swap.h"

static void	ft_swap(int *a, int *b)
{
	int	c;

	c = *a;
	*a = *b;
	*b = c;
}

void	swappie(t_stack **st)
{
	t_stack	*top;
	t_stack	*next;

	if (ft_lstsize(*st) < 2)
		return ;
	top = *st;
	next = top->next;
	if (!top && !next)
		puterror ("Erorr: Swap has failed ");
	ft_swap(&top->val, &next->val);
	ft_swap(&top->marker, &next->marker);
}

void	sa(t_stack **a, int x)
{
	swappie(a);
	if (x == 1)
		ft_putstr_fd("sa\n", 1);
}

void	sb(t_stack **b, int x)
{
	swappie(b);
	if (x == 1)
		ft_putstr_fd("sb\n", 1);
}

void	ss(t_stack **a, t_stack **b, int x)
{	
	if ((ft_lstsize(*a) < 2) || (ft_lstsize(*b) < 2))
		return ;
	swappie(a);
	swappie(b);
	if (x == 1)
		ft_putstr_fd("ss\n", 1);
}
