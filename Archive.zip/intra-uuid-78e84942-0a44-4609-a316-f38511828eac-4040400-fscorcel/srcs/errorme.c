/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   errorme.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fscorcel <fscorcel@student.42barcel>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/05 13:45:32 by fscorcel          #+#    #+#             */
/*   Updated: 2022/03/21 12:37:19 by fscorcel         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../push_swap.h"

void	puterror(char *s)
{
	ft_putstr_fd(s, 2);
	exit(EXIT_FAILURE);
}

void	free_stack(t_stack **st)
{
	t_stack	*aux;
	t_stack	*top;

	top = *st;
	while (top)
	{
		aux = top;
		top = top->next;
		if (aux)
			free(aux);
	}
	top = NULL;
	free(st);
}

void	free_str(char **s)
{
	if (s == NULL)
		return ;
	free(*s);
	s = NULL;
}
