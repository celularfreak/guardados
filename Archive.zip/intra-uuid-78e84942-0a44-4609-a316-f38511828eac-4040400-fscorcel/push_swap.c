/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fscorcel <fscorcel@student.42barcel>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/05 13:45:47 by fscorcel          #+#    #+#             */
/*   Updated: 2022/03/16 15:47:06 by fscorcel         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

static t_stack	*get_min(t_stack **st)
{
	t_stack		*top;
	t_stack		*minim;
	int			got_min;

	minim = NULL;
	got_min = 0;
	top = *st;
	if (top)
	{
		while (top)
		{
			if ((top->marker == -1)
				&& (!got_min || top->val < minim->val))
			{
				minim = top;
				got_min = 1;
			}
			top = top->next;
		}
	}
	return (minim);
}

static void	get_marker(t_stack **st)
{
	t_stack		*top;
	int			marker;

	marker = 0;
	top = get_min(st);
	while (top)
	{
		top->marker = marker++;
		top = get_min(st);
	}
}

void	stackmaker(t_stack **st, int ac, char **av)
{
	t_stack		*new;
	char		**args;
	int			i;

	i = 0;
	if (ac == 2)
		args = ft_split(av[1], ' ');
	else
	{
		i = 1;
		args = av;
	}
	while (args[i])
	{
		new = ft_lstnew((int)ft_atoi(args[i]));
		ft_lstadd_back(st, new);
		i++;
	}
	get_marker(st);
	if (ac == 2)
		free_str(args);
}

int	main(int ac, char **av)
{
	t_stack	**a;
	t_stack	**b;

	if (ac > 2)
	{
		args_checker(ac, av);
		a = (t_stack **)malloc(sizeof(t_stack));
		b = (t_stack **)malloc(sizeof(t_stack));
		stackmaker(a, ac, av);
		if (is_done(a))
		{
			free_stack(a);
			free_stack(b);
		}
		else
		{
			sorter(a, b);
			free_stack(a);
			free_stack(b);
		}
	}
	return (0);
}
