/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstadd_back.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fscorcel <fscorcel@student.42barcel>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/25 12:38:42 by fscorcel          #+#    #+#             */
/*   Updated: 2022/03/16 15:43:30 by fscorcel         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	ft_lstadd_back(t_stack **st, t_stack *new)
{
	t_stack	*lastnode;

	if (!new)
		return ;
	if (!*st)
	{
		*st = new;
		return ;
	}
	lastnode = ft_lstlast(*st);
	lastnode->next = new;
}
