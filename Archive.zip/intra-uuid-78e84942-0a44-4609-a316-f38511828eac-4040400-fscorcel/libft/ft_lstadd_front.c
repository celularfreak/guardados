/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstadd_front.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fscorcel <fscorcel@student.42barcel>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/24 12:48:42 by fscorcel          #+#    #+#             */
/*   Updated: 2022/03/16 15:43:21 by fscorcel         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	ft_lstadd_front(t_stack **st, t_stack *new)
{
	if (!new)
		return ;
	if (!st)
	{
		*st = new;
		return ;
	}	
	new->next = *st;
	*st = new;
}
