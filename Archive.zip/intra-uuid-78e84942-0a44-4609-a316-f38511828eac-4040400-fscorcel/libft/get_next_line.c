/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fscorcel <fscorcel@student.42barcel>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/28 11:55:39 by fscorcel          #+#    #+#             */
/*   Updated: 2022/02/08 11:48:47 by fscorcel         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static char	*ft_nwline(char **mybuff, char **newline)
{
	char	*temp;
	int		c;

	c = 0;
	if (!*mybuff)
		return (NULL);
	if (!**mybuff)
	{
		free(*mybuff);
		return (NULL);
	}
	while ((*mybuff)[c] != '\n' && (*mybuff)[c] != '\0')
		c++;
	if ((*mybuff)[c] != '\n')
	{
		*newline = ft_substr(*mybuff, 0, c);
		free(*mybuff);
		*mybuff = NULL;
		return (*newline);
	}
	*newline = ft_substr(*mybuff, 0, c + 1);
	temp = *mybuff;
	*mybuff = ft_substr(*mybuff, c + 1, ft_strlen(*mybuff) - c);
	free(temp);
	return (*newline);
}

static	char	*ft_read(int fd, char **mybuff, char *buffer)
{
	int		byte;
	char	*aux;

	if (!*mybuff || !(ft_strchr(*mybuff, '\n')))
	{
		byte = read(fd, buffer, BUFFER_SIZE);
		while (byte > 0)
		{
			buffer[byte] = 0;
			if (!*mybuff)
				*mybuff = ft_strdup(buffer);
			else
			{
				aux = *mybuff;
				*mybuff = ft_strjoin(aux, buffer);
				free(aux);
			}
			if (ft_strchr(buffer, '\n'))
				break ;
			byte = read(fd, buffer, BUFFER_SIZE);
		}
	}
	return (*mybuff);
}

char	*get_next_line(int fd)
{
	char		buffer[BUFFER_SIZE + 1];
	static char	*mybuff;
	char		*newline;

	newline = 0;
	if (!(BUFFER_SIZE) || fd < 0)
		return (NULL);
	ft_read(fd, &mybuff, buffer);
	ft_nwline(&mybuff, &newline);
	return (newline);
}
