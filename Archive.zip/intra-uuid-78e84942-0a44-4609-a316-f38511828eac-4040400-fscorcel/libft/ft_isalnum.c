/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isalnum.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fscorcel <fscorcel@student.42barcelona.co  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/10 13:23:39 by fscorcel          #+#    #+#             */
/*   Updated: 2022/03/16 15:30:33 by fscorcel         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	ft_isalnum(char *num)

{
	int	i;

	i = -1;
	while (num[++i])
	{
		if (num[i] == '-')
			i++;
		if (ft_isdigit(num[i]) == 0)
			return (0);
	}
	return (1);
}
