/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlen.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lmartin2 <lmartin2@student.42bcn.com>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/12 16:58:54 by lmartin2          #+#    #+#             */
/*   Updated: 2022/02/24 14:13:13 by lmartin2         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//La ft_strlen reproduce la función ft_strlen como se define en el man. 

#include "libft.h"

size_t	ft_strlen(const char *s)
{
	size_t	len;

	len = 0;
	while (*(s++))
		len++;
	return (len);
}
