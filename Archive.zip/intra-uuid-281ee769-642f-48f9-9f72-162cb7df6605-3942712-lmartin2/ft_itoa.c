/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_itoa.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lmartin2 <lmartin2@student.42bcn.com>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/23 21:48:14 by lmartin2          #+#    #+#             */
/*   Updated: 2022/02/24 16:21:46 by lmartin2         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static int	intlen(int num)
{
	int	len;
	int	sign;

	if (num == 0 || num == -0)
		return (1);
	sign = 0;
	if (num < 0)
		sign = 1;
	len = 0;
	while (num)
	{
		num /= 10;
		len++;
	}
	return (sign + len);
}

char	*ft_itoa(int n)
{
	int			len;
	long int	nbr;
	char		*str;

	len = intlen(n);
	nbr = (long int)n;
	if (n < 0)
		nbr *= -1;
	str = (char *)malloc(sizeof(char) * (len + 1));
	if (!str)
		return (NULL);
	str[len--] = '\0';
	while (len >= 0)
	{
		str[len--] = nbr % 10 + '0';
		nbr /= 10;
	}
	if (n < 0)
		*str = '-';
	return (str);
}
